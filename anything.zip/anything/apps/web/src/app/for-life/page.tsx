import Navbar from '@/components/navbar';
import Footer from '@/components/footer';
import { Button } from '@/components/ui/button';
import { Heart, Users, Clock, Moon, Sparkles, ArrowRight } from 'lucide-react';
import Link from 'next/link';

const LIFE_RESOURCES = [
  { title: 'Relationship Guide by Type', format: 'PDF', icon: <Heart className="w-5 h-5" /> },
  { title: 'My Daily Rhythm Planner', format: 'PRINTABLE', icon: <Clock className="w-5 h-5" /> },
  { title: 'Parenting Your Type', format: 'MINI GUIDE', icon: <Users className="w-5 h-5" /> },
];

export default function ForLifePage() {
  return (
    <div className="min-h-screen bg-brand-cream">
      <Navbar />

      <main>
        {/* Hero */}
        <section className="px-6 py-24 text-center max-w-4xl mx-auto">
          <div className="flex items-center justify-center space-x-3 text-brand-terracotta font-accent text-[10px] uppercase tracking-[0.2em] mb-8">
            <Heart className="w-4 h-4" /> <span>Human Design × Life</span>
          </div>
          <h1 className="font-display text-5xl md:text-7xl text-brand-inkblue mb-8 leading-tight">
            Design a life that <br className="hidden md:block" />
            <span className="italic">fits your soul.</span>
          </h1>
          <p className="font-body text-lg text-brand-charcoal/70 mb-12">
            HD for the actual life you're living — not a perfect spiritual practice. From parenting
            to relationships, find your rhythm.
          </p>
          <Link href="/calculator">
            <Button
              size="lg"
              className="bg-brand-terracotta hover:bg-brand-inkblue text-brand-cream rounded-full px-10 py-7 font-accent text-xs uppercase tracking-widest"
            >
              Get Your Personal Chart
            </Button>
          </Link>
        </section>

        {/* Relationships Block */}
        <section className="px-6 py-24 bg-white/40">
          <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-20 items-center">
            <div className="bg-brand-sage/10 p-12 rounded-[60px] border border-brand-sage/20 relative">
              <Moon className="absolute top-8 right-8 text-brand-sage/30 w-12 h-12" />
              <h3 className="font-display text-3xl text-brand-inkblue mb-6">Relationships × HD</h3>
              <p className="font-body text-brand-charcoal/70 leading-relaxed mb-8">
                Stop trying to fix your partner and start understanding their design. When you know
                how someone else processes energy and emotions, compassion becomes the default
                setting.
              </p>
              <ul className="space-y-4 font-accent text-[10px] uppercase tracking-widest text-brand-inkblue">
                <li className="flex items-center">
                  <Sparkles className="w-3 h-3 mr-3 text-brand-sage" /> Type compatibility insights
                </li>
                <li className="flex items-center">
                  <Sparkles className="w-3 h-3 mr-3 text-brand-sage" /> Authority in partnership
                </li>
                <li className="flex items-center">
                  <Sparkles className="w-3 h-3 mr-3 text-brand-sage" /> Communication by center
                </li>
              </ul>
            </div>
            <div className="space-y-8">
              <h2 className="font-display text-4xl text-brand-inkblue italic">
                "Parenting is hard enough. Don't parent against your child's design."
              </h2>
              <p className="font-body text-brand-charcoal/70 leading-relaxed">
                Understanding your children's Human Design types can transform the dynamic of your
                home. Learn why your Projector child needs more rest, or why your Manifestor child
                needs to be informed, not controlled.
              </p>
              <Link href="/calculator">
                <Button
                  variant="link"
                  className="p-0 font-accent text-xs uppercase tracking-widest text-brand-terracotta"
                >
                  Start with a child's chart →
                </Button>
              </Link>
            </div>
          </div>
        </section>

        {/* Daily Rhythms */}
        <section className="px-6 py-32 max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-20 items-center">
            <div className="space-y-8">
              <h2 className="font-display text-4xl text-brand-inkblue">Daily Rhythms × HD</h2>
              <p className="font-body text-brand-charcoal/70 leading-relaxed">
                Scheduling based on your type's natural energy cycles is the ultimate act of
                self-care. It's not about being productive; it's about being sustainable.
              </p>
              <div className="space-y-6">
                <div className="border-l-2 border-brand-gold pl-6">
                  <h4 className="font-accent text-[10px] uppercase tracking-widest text-brand-gold mb-1">
                    For Generators / MGs
                  </h4>
                  <p className="font-body text-sm text-brand-charcoal/70">
                    Use your energy until it's gone. Then sleep.
                  </p>
                </div>
                <div className="border-l-2 border-brand-sage pl-6">
                  <h4 className="font-accent text-[10px] uppercase tracking-widest text-brand-sage mb-1">
                    For Projectors / Manifestors
                  </h4>
                  <p className="font-body text-sm text-brand-charcoal/70">
                    Rest *before* you are tired. Your capacity is limited.
                  </p>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="h-64 bg-brand-blush/30 rounded-[40px] border border-brand-blush/50"></div>
              <div className="h-64 bg-brand-terracotta/10 rounded-[40px] border border-brand-terracotta/20 mt-12"></div>
            </div>
          </div>
        </section>

        {/* Resources */}
        <section className="bg-brand-inkblue py-24 px-6 text-brand-cream">
          <div className="max-w-7xl mx-auto">
            <h2 className="font-display text-4xl mb-12">Life & Family Resources</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {LIFE_RESOURCES.map((res) => (
                <div
                  key={res.title}
                  className="bg-white/5 border border-white/10 p-8 rounded-3xl hover:bg-white/10 transition-all cursor-pointer group"
                >
                  <div className="text-brand-gold mb-6">{res.icon}</div>
                  <h3 className="font-display text-2xl mb-2">{res.title}</h3>
                  <p className="font-accent text-[10px] text-brand-blush/50 uppercase tracking-widest mb-8">
                    {res.format}
                  </p>
                  <Button
                    variant="ghost"
                    className="p-0 text-brand-gold font-accent text-[10px] uppercase tracking-widest group-hover:translate-x-1 transition-transform"
                  >
                    Get It Free →
                  </Button>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
