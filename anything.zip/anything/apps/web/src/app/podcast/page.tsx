import Navbar from '@/components/navbar';
import Footer from '@/components/footer';
import { Button } from '@/components/ui/button';
import { Headphones, Filter, Play, ArrowRight, Rss } from 'lucide-react';

const EPISODES = [
  {
    id: 1,
    title: "Why You're Exhausted (And It's Not Laziness)",
    duration: '4:12',
    category: 'Projectors',
    tags: ['Business', 'Burnout'],
  },
  {
    id: 2,
    title: "The Real Reason You Can't Make That Decision",
    duration: '5:45',
    category: 'Authority',
    tags: ['Life', 'Relationships'],
  },
  {
    id: 3,
    title: 'Generator Energy 101: What Sustainable Actually Feels Like',
    duration: '3:50',
    category: 'Generators',
    tags: ['Life'],
  },
  {
    id: 4,
    title: 'How Your Authority Messes With Your Business Pricing',
    duration: '6:15',
    category: 'Business',
    tags: ['Business', 'Pricing'],
  },
  {
    id: 5,
    title: "Open Solar Plexus: Why You're Always 'Too Emotional'",
    duration: '4:30',
    category: 'Centers',
    tags: ['Life', 'Emotions'],
  },
];

const CATEGORIES = ['All', 'For Business', 'For Life', 'Type Deep Dive', 'Authority', 'Centers'];

export default function PodcastPage() {
  return (
    <div className="min-h-screen bg-brand-cream">
      <Navbar />

      <main className="max-w-7xl mx-auto px-6 py-20">
        <header className="mb-20">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-12">
            <div className="max-w-2xl">
              <h1 className="font-display text-5xl md:text-7xl text-brand-inkblue mb-8 leading-tight">
                The Messy <br />
                <span className="italic text-brand-terracotta">Blueprint.</span>
              </h1>
              <p className="font-body text-lg text-brand-charcoal/70 leading-relaxed mb-8">
                3–5 minute single-topic explainers for the actual life you're living. No fluff, no
                jargon, just the HD you need for your actual Tuesday.
              </p>
              <div className="flex flex-wrap gap-4 items-center">
                <Button className="bg-brand-terracotta hover:bg-brand-inkblue text-brand-cream rounded-full px-8 py-6 font-accent text-[10px] uppercase tracking-widest">
                  Subscribe on Spotify
                </Button>
                <Button
                  variant="outline"
                  className="border-brand-inkblue/10 text-brand-inkblue rounded-full px-8 py-6 font-accent text-[10px] uppercase tracking-widest hover:bg-white"
                >
                  Apple Podcasts
                </Button>
                <button className="flex items-center text-brand-charcoal/40 font-accent text-[10px] uppercase tracking-widest hover:text-brand-terracotta">
                  <Rss className="w-3 h-3 mr-2" /> RSS Feed
                </button>
              </div>
            </div>

            <div className="hidden md:block">
              <div className="bg-brand-blush/30 p-10 rounded-[40px] border border-brand-blush/50 relative overflow-hidden">
                <div className="relative z-10 flex flex-col items-center">
                  <Headphones className="text-brand-terracotta w-10 h-10 mb-6" />
                  <p className="font-accent text-[10px] uppercase tracking-[0.3em] text-brand-inkblue mb-2">
                    New Episode Every Monday
                  </p>
                  <p className="font-handwriting text-2xl text-brand-terracotta">
                    Brief & Beautiful
                  </p>
                </div>
                <div className="absolute top-0 right-0 w-24 h-24 bg-brand-terracotta/5 rounded-full -mr-12 -mt-12"></div>
              </div>
            </div>
          </div>
        </header>

        {/* Filter */}
        <div className="flex flex-wrap gap-3 mb-16 items-center">
          <Filter className="w-4 h-4 text-brand-charcoal/40 mr-2" />
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              className={`font-accent text-[10px] uppercase tracking-widest px-6 py-2.5 rounded-full transition-all border ${cat === 'All' ? 'bg-brand-inkblue text-brand-cream border-brand-inkblue' : 'bg-transparent text-brand-charcoal border-brand-inkblue/10 hover:border-brand-terracotta'}`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Episodes Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
          {EPISODES.map((ep) => (
            <div
              key={ep.id}
              className="group relative bg-white rounded-[32px] p-8 border border-brand-cream hover:border-brand-terracotta hover:shadow-xl hover:shadow-brand-terracotta/5 transition-all"
            >
              <div className="flex justify-between items-start mb-8">
                <span className="text-[10px] font-accent uppercase tracking-widest text-brand-terracotta/60 bg-brand-terracotta/5 px-3 py-1 rounded-full">
                  {ep.category}
                </span>
                <span className="text-[10px] font-accent uppercase tracking-widest text-brand-charcoal/30 flex items-center">
                  <Play className="w-3 h-3 mr-1 fill-current" /> {ep.duration}
                </span>
              </div>

              <h3 className="font-display text-2xl text-brand-inkblue mb-8 leading-snug min-h-[4rem]">
                {ep.title}
              </h3>

              <div className="flex items-center justify-between">
                <div className="flex gap-2">
                  {ep.tags.map((tag) => (
                    <span
                      key={tag}
                      className="text-[9px] font-accent uppercase tracking-widest text-brand-charcoal/40"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
                <button className="w-10 h-10 bg-brand-cream rounded-full flex items-center justify-center text-brand-terracotta group-hover:bg-brand-terracotta group-hover:text-brand-cream transition-all">
                  <Play size={16} fill="currentColor" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <section className="bg-brand-inkblue rounded-[60px] p-12 md:p-20 text-center relative overflow-hidden">
          <div className="relative z-10 max-w-2xl mx-auto">
            <h2 className="font-display text-4xl md:text-5xl text-brand-cream mb-8">
              Never miss a lesson.
            </h2>
            <p className="font-body text-brand-blush/70 mb-12">
              Join 5,000+ women who get the "Messy Monday" newsletter with the latest episode and
              human design insights.
            </p>
            <form className="flex flex-col md:flex-row gap-4">
              <input
                type="email"
                placeholder="Your email address"
                className="flex-grow bg-white/10 border border-white/20 rounded-full px-8 py-5 text-brand-cream font-body outline-none focus:border-brand-gold transition-colors"
              />
              <Button className="bg-brand-gold hover:bg-brand-cream text-brand-inkblue rounded-full px-10 py-5 font-accent text-xs uppercase tracking-widest">
                Join Us
              </Button>
            </form>
          </div>
          <div className="absolute top-0 left-0 w-64 h-64 bg-brand-gold/5 rounded-full -ml-32 -mt-32"></div>
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-brand-terracotta/5 rounded-full -mr-48 -mb-48"></div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
