import Navbar from '@/components/navbar';
import Footer from '@/components/footer';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { ArrowRight, Play, Headphones, BookOpen, Star } from 'lucide-react';

const TYPES = [
  {
    name: 'Projector',
    essence: 'The Guide',
    desc: 'You were built to guide, not grind.',
    color: 'bg-brand-sage',
  },
  {
    name: 'Generator',
    essence: 'The Builder',
    desc: 'The engine of the world when in joy.',
    color: 'bg-brand-terracotta',
  },
  {
    name: 'Manifesting Generator',
    essence: 'The Multi-Hyphenate',
    desc: 'Efficient, fast, and multi-passionate.',
    color: 'bg-brand-gold',
  },
  {
    name: 'Manifestor',
    essence: 'The Initiator',
    desc: 'The spark that starts the fire.',
    color: 'bg-brand-inkblue',
  },
  {
    name: 'Reflector',
    essence: 'The Mirror',
    desc: 'The rare soul who mirrors the community.',
    color: 'bg-brand-blush',
  },
];

const RESOURCES = [
  { title: "What's My Type? Starter Kit", format: 'PDF', category: 'Chart Guides' },
  { title: 'Content Strategy by Type', format: 'SWIPE PDF', category: 'Business' },
  { title: 'The Messy Middle Rhythm Planner', format: 'PRINTABLE', category: 'Life' },
];

const EPISODES = [
  {
    title: "Why You're Exhausted (And It's Not Laziness)",
    duration: '4 min',
    category: 'Projectors',
  },
  {
    title: "The Real Reason You Can't Make That Decision",
    duration: '5 min',
    category: 'Authority',
  },
  {
    title: 'Generator Energy: What Sustainable Feels Like',
    duration: '3 min',
    category: 'Generators',
  },
];

export default function HomePage() {
  return (
    <div className="min-h-screen bg-brand-cream">
      <Navbar />

      {/* Hero Section */}
      <section className="px-6 py-20 md:py-32 max-w-7xl mx-auto text-center relative overflow-hidden">
        <div className="relative z-10">
          <h1 className="font-display text-5xl md:text-7xl lg:text-8xl text-brand-inkblue max-w-5xl mx-auto leading-[1.1] mb-8">
            You were designed <br className="hidden md:block" />
            <span className="italic">for this.</span>
          </h1>
          <p className="font-handwriting text-2xl md:text-3xl text-brand-terracotta mb-8">
            All of it — the business, the babies, the becoming.
          </p>
          <p className="font-body text-lg md:text-xl text-brand-charcoal/80 max-w-2xl mx-auto mb-12">
            Human Design simplified for women who are doing too much and still not done.
          </p>
          <div className="flex flex-col md:flex-row items-center justify-center space-y-4 md:space-y-0 md:space-x-6">
            <Link href="/calculator">
              <Button
                size="lg"
                className="bg-brand-terracotta hover:bg-brand-inkblue text-brand-cream rounded-full px-8 py-7 text-sm font-accent uppercase tracking-widest"
              >
                Get Your Free Chart <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </Link>
            <Link
              href="#podcast"
              className="font-accent text-xs uppercase tracking-widest text-brand-charcoal hover:text-brand-terracotta transition-colors flex items-center"
            >
              Listen to the Podcast <ArrowRight className="ml-2 w-4 h-4 rotate-90" />
            </Link>
          </div>
        </div>

        {/* Decorative Element */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] opacity-5 pointer-events-none">
          <svg viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M100 10L120 40H80L100 10Z" stroke="currentColor" strokeWidth="1" />
            <rect x="80" y="50" width="40" height="30" stroke="currentColor" strokeWidth="1" />
            <rect x="75" y="90" width="50" height="40" stroke="currentColor" strokeWidth="1" />
            <path d="M100 140L130 170H70L100 140Z" stroke="currentColor" strokeWidth="1" />
            <circle
              cx="100"
              cy="100"
              r="80"
              stroke="currentColor"
              strokeWidth="0.5"
              strokeDasharray="4 4"
            />
          </svg>
        </div>
      </section>

      {/* What is HD Section */}
      <section className="bg-white/50 py-24 px-6">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-16 items-start">
          <div className="space-y-6">
            <h2 className="font-display text-3xl text-brand-inkblue">What is Human Design?</h2>
            <p className="font-body text-brand-charcoal/70 leading-relaxed">
              Think of it as your soul's blueprint. A mix of ancient wisdom and modern science that
              shows you exactly how your energy works, how you're meant to make decisions, and where
              you're prone to burnout.
            </p>
          </div>
          <div className="space-y-6">
            <h2 className="font-display text-3xl text-brand-inkblue">Why it matters for YOU</h2>
            <p className="font-body text-brand-charcoal/70 leading-relaxed">
              Because trying to run a business and a household like a "traditional" achiever is a
              recipe for resentment. HD gives you permission to do things differently — in a way
              that actually feels like <span className="italic">relief.</span>
            </p>
          </div>
          <div className="bg-brand-blush/30 p-8 rounded-2xl border border-brand-blush/50">
            <Star className="text-brand-terracotta mb-4 w-6 h-6" />
            <p className="font-display text-xl text-brand-inkblue mb-4 italic">
              "1 in 5 women is a Projector. Most are burning out trying to work like Generators."
            </p>
            <Link
              href="/calculator"
              className="font-accent text-xs uppercase tracking-widest text-brand-terracotta flex items-center group"
            >
              Start with your free chart{' '}
              <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
        </div>
      </section>

      {/* Type Overview Strip */}
      <section className="py-24 overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 mb-12 flex justify-between items-end">
          <div>
            <h2 className="font-display text-4xl text-brand-inkblue mb-4">Meet the 5 Types</h2>
            <p className="font-body text-brand-charcoal/60">
              The primary archetypes of human energy.
            </p>
          </div>
          <Link
            href="/types"
            className="font-accent text-xs uppercase tracking-widest text-brand-charcoal border-b border-brand-charcoal/20 pb-1"
          >
            View all types
          </Link>
        </div>

        <div className="flex overflow-x-auto pb-12 px-6 md:px-[calc((100vw-1280px)/2)] gap-6 no-scrollbar">
          {TYPES.map((type) => (
            <Link
              key={type.name}
              href={`/types/${type.name.toLowerCase().replace(' ', '-')}`}
              className="min-w-[300px] bg-white p-8 rounded-3xl shadow-sm border border-brand-cream hover:border-brand-terracotta transition-all group"
            >
              <div
                className={`w-12 h-12 rounded-full ${type.color} mb-8 opacity-80 group-hover:opacity-100 transition-opacity`}
              ></div>
              <h3 className="font-display text-2xl text-brand-inkblue mb-2">{type.name}</h3>
              <p className="font-accent text-[10px] uppercase tracking-widest text-brand-terracotta mb-4">
                {type.essence}
              </p>
              <p className="font-body text-sm text-brand-charcoal/60 leading-relaxed mb-8">
                {type.desc}
              </p>
              <div className="flex items-center text-brand-inkblue font-accent text-[10px] uppercase tracking-widest">
                Learn more{' '}
                <ArrowRight className="ml-2 w-3 h-3 group-hover:translate-x-1 transition-transform" />
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Freemium Hub Preview */}
      <section className="py-24 bg-brand-inkblue text-brand-cream">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl md:text-5xl mb-6">Free Resource Library</h2>
            <p className="font-body text-brand-blush/70 max-w-xl mx-auto">
              Guides, swipe files, and tools designed for the messy middle of building and being.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {RESOURCES.map((res) => (
              <div
                key={res.title}
                className="bg-white/5 border border-white/10 p-10 rounded-3xl flex flex-col justify-between hover:bg-white/10 transition-colors"
              >
                <div>
                  <div className="font-accent text-[10px] uppercase tracking-widest text-brand-gold mb-6 flex items-center">
                    <BookOpen className="w-4 h-4 mr-2" /> {res.category}
                  </div>
                  <h3 className="font-display text-2xl mb-4">{res.title}</h3>
                </div>
                <div className="mt-12 flex items-center justify-between">
                  <span className="font-accent text-[10px] text-brand-blush/50 uppercase tracking-widest">
                    {res.format}
                  </span>
                  <Button
                    variant="ghost"
                    className="text-brand-gold font-accent text-xs uppercase tracking-widest hover:text-brand-cream hover:bg-transparent p-0"
                  >
                    Grab your freebie →
                  </Button>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-16 text-center">
            <Link href="/free-resources">
              <Button
                variant="outline"
                className="border-brand-gold text-brand-gold hover:bg-brand-gold hover:text-brand-inkblue rounded-full px-8 py-6 font-accent text-xs uppercase tracking-widest"
              >
                Explore All Resources
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Podcast Strip */}
      <section id="podcast" className="py-24 px-6 bg-brand-cream border-t border-brand-inkblue/5">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-16 space-y-6 md:space-y-0">
            <div>
              <h2 className="font-display text-4xl text-brand-inkblue mb-4">
                The Messy Blueprint Podcast
              </h2>
              <p className="font-body text-brand-charcoal/60">
                3–5 minute single-topic explainers for your actual life.
              </p>
            </div>
            <div className="flex items-center space-x-6 opacity-40">
              <Headphones className="w-5 h-5" />
              <span className="font-accent text-[10px] uppercase tracking-widest">Spotify</span>
              <span className="font-accent text-[10px] uppercase tracking-widest">Apple</span>
              <span className="font-accent text-[10px] uppercase tracking-widest">YouTube</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {EPISODES.map((ep) => (
              <div key={ep.title} className="group relative">
                <div className="bg-brand-blush/20 p-8 rounded-3xl border border-brand-blush/40 group-hover:bg-brand-blush/40 transition-all">
                  <div className="flex justify-between items-start mb-6">
                    <span className="bg-brand-terracotta/10 text-brand-terracotta text-[10px] font-accent uppercase tracking-widest px-3 py-1 rounded-full">
                      {ep.category}
                    </span>
                    <span className="text-brand-charcoal/40 text-[10px] font-accent uppercase tracking-widest flex items-center">
                      <Play className="w-3 h-3 mr-1 fill-current" /> {ep.duration}
                    </span>
                  </div>
                  <h3 className="font-display text-xl text-brand-inkblue mb-6 leading-snug">
                    {ep.title}
                  </h3>
                  <button className="flex items-center text-brand-terracotta font-accent text-[10px] uppercase tracking-widest group-hover:translate-x-1 transition-transform">
                    Listen Now <ArrowRight className="ml-2 w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <Footer />

      <style jsx global>{`
        .no-scrollbar::-webkit-scrollbar {
          display: none;
        }
        .no-scrollbar {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
    </div>
  );
}
