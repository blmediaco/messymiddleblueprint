import Navbar from '@/components/navbar';
import Footer from '@/components/footer';
import { Button } from '@/components/ui/button';
import { BookOpen, Download, Lock, CheckCircle2 } from 'lucide-react';

const RESOURCES = [
  {
    title: "What's My Type? Starter Kit",
    category: 'Chart Guides',
    format: 'PDF',
    desc: 'A 20-page deep dive into the 5 archetypes and how they actually function in the wild.',
  },
  {
    title: 'Content Strategy by Type',
    category: 'Business',
    format: 'Swipe PDF',
    desc: "Stop shouting into the void. Use your type's natural frequency to attract the right people.",
  },
  {
    title: 'The Messy Middle Daily Rhythm Planner',
    category: 'Life',
    format: 'Printable',
    desc: 'A physical planner page designed to help you track your energy and output based on your HD type.',
  },
  {
    title: 'Decision-Making by Authority',
    category: 'Reference',
    format: 'Reference Sheet',
    desc: 'Keep this on your desk for the next time you have to say yes or no to a big opportunity.',
  },
  {
    title: "Projector's Invitation Tracker",
    category: 'Specialized',
    format: 'Printable',
    desc: "A tool to help Projectors track when they've been recognized and invited into new energy.",
  },
  {
    title: "Generator's Response Journal",
    category: 'Specialized',
    format: 'PDF',
    desc: 'Prompts to help you reconnect with your gut response after years of people-pleasing.',
  },
];

export default function FreeResourcesPage() {
  return (
    <div className="min-h-screen bg-brand-cream">
      <Navbar />

      <main className="max-w-7xl mx-auto px-6 py-20">
        <header className="text-center mb-24 max-w-3xl mx-auto">
          <div className="inline-flex items-center space-x-2 bg-brand-terracotta/10 text-brand-terracotta px-4 py-2 rounded-full font-accent text-[9px] uppercase tracking-widest mb-8">
            <SparklesIcon className="w-3 h-3" /> <span>The Freemium Hub</span>
          </div>
          <h1 className="font-display text-5xl md:text-7xl text-brand-inkblue mb-8">
            Tools for the <br />
            <span className="italic text-brand-terracotta">messy middle.</span>
          </h1>
          <p className="font-body text-lg text-brand-charcoal/70">
            A library of free, high-value resources designed to help you integrate Human Design into
            your actual business and life. No heavy sales pressure, just help.
          </p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {RESOURCES.map((res) => (
            <div
              key={res.title}
              className="bg-white rounded-[40px] border border-brand-blush/30 p-10 flex flex-col justify-between hover:border-brand-terracotta transition-all group"
            >
              <div>
                <div className="flex justify-between items-start mb-8">
                  <span className="font-accent text-[9px] uppercase tracking-widest text-brand-inkblue/40 border border-brand-inkblue/10 px-3 py-1 rounded-full">
                    {res.category}
                  </span>
                  <Download className="w-5 h-5 text-brand-terracotta/40 group-hover:text-brand-terracotta transition-colors" />
                </div>
                <h3 className="font-display text-2xl text-brand-inkblue mb-4 group-hover:text-brand-terracotta transition-colors">
                  {res.title}
                </h3>
                <p className="font-body text-sm text-brand-charcoal/60 leading-relaxed mb-8">
                  {res.desc}
                </p>
              </div>

              <div className="pt-8 border-t border-brand-cream flex items-center justify-between">
                <span className="font-accent text-[10px] text-brand-charcoal/30 uppercase tracking-widest">
                  {res.format}
                </span>
                <Button className="bg-brand-inkblue hover:bg-brand-terracotta text-brand-cream rounded-full font-accent text-[9px] uppercase tracking-widest h-10 px-6">
                  Get Access
                </Button>
              </div>
            </div>
          ))}
        </div>

        {/* Email Capture Block */}
        <section className="mt-32 bg-brand-blush/30 rounded-[60px] p-12 md:p-20 relative overflow-hidden">
          <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="font-display text-4xl text-brand-inkblue mb-6">
                Unlock the full library.
              </h2>
              <p className="font-body text-brand-charcoal/70 mb-8">
                Join our community and get instant access to every resource on this page, plus
                weekly human design insights delivered to your inbox.
              </p>
              <ul className="space-y-4">
                {['Instant download links', 'Type-specific deep dives', 'No spam, just soul'].map(
                  (item) => (
                    <li
                      key={item}
                      className="flex items-center text-sm font-body text-brand-inkblue/80"
                    >
                      <CheckCircle2 className="w-4 h-4 mr-3 text-brand-sage" /> {item}
                    </li>
                  )
                )}
              </ul>
            </div>
            <div className="bg-white p-10 rounded-[40px] shadow-xl shadow-brand-terracotta/5 border border-brand-blush/50">
              <form className="space-y-6">
                <div className="space-y-2">
                  <label className="font-accent text-[9px] uppercase tracking-widest text-brand-charcoal/50 ml-1">
                    Your Name
                  </label>
                  <input
                    type="text"
                    className="w-full bg-brand-cream/50 border border-brand-blush/30 rounded-2xl px-6 py-4 outline-none focus:border-brand-terracotta transition-colors"
                  />
                </div>
                <div className="space-y-2">
                  <label className="font-accent text-[9px] uppercase tracking-widest text-brand-charcoal/50 ml-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    className="w-full bg-brand-cream/50 border border-brand-blush/30 rounded-2xl px-6 py-4 outline-none focus:border-brand-terracotta transition-colors"
                  />
                </div>
                <Button className="w-full bg-brand-terracotta hover:bg-brand-inkblue text-brand-cream rounded-2xl py-6 font-accent text-xs uppercase tracking-widest">
                  Access the Library
                </Button>
              </form>
            </div>
          </div>
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/40 rounded-full -mr-32 -mt-32"></div>
        </section>
      </main>

      <Footer />
    </div>
  );
}

function SparklesIcon({ className }: { className?: string }) {
  return (
    <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"
      />
    </svg>
  );
}
