import Link from 'next/link';

export default function Navbar() {
  return (
    <nav className="flex items-center justify-between px-6 py-8 md:px-12 max-w-7xl mx-auto w-full">
      <Link
        href="/"
        className="font-display text-2xl md:text-3xl text-brand-inkblue font-semibold tracking-tight"
      >
        Uncharted, Loved
      </Link>

      <div className="hidden md:flex items-center space-x-8 font-accent text-xs uppercase tracking-widest text-brand-charcoal">
        <Link href="/calculator" className="hover:text-brand-terracotta transition-colors">
          Calculator
        </Link>
        <Link href="/types" className="hover:text-brand-terracotta transition-colors">
          Types
        </Link>
        <Link href="/for-business" className="hover:text-brand-terracotta transition-colors">
          Business
        </Link>
        <Link href="/podcast" className="hover:text-brand-terracotta transition-colors">
          Podcast
        </Link>
        <Link href="/free-resources" className="hover:text-brand-terracotta transition-colors">
          Resources
        </Link>
      </div>

      <Link
        href="/calculator"
        className="bg-brand-terracotta text-brand-cream px-6 py-2.5 rounded-full font-accent text-xs uppercase tracking-widest hover:bg-brand-inkblue transition-all"
      >
        Free Chart
      </Link>
    </nav>
  );
}
