import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-brand-inkblue text-brand-cream pt-20 pb-10 px-6">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12 border-b border-brand-cream/10 pb-20">
        <div className="md:col-span-1">
          <h3 className="font-display text-2xl mb-6">Uncharted, Loved</h3>
          <p className="font-body text-brand-blush/80 leading-relaxed max-w-xs">
            Human Design for women who are building, raising, and becoming — all at once.
          </p>
        </div>

        <div>
          <h4 className="font-accent text-xs uppercase tracking-widest mb-6 text-brand-gold">
            Explore
          </h4>
          <ul className="space-y-4 font-body text-sm">
            <li>
              <Link href="/calculator" className="hover:text-brand-terracotta">
                Free Chart Calculator
              </Link>
            </li>
            <li>
              <Link href="/types" className="hover:text-brand-terracotta">
                The 5 Types
              </Link>
            </li>
            <li>
              <Link href="/for-business" className="hover:text-brand-terracotta">
                Human Design × Business
              </Link>
            </li>
            <li>
              <Link href="/for-life" className="hover:text-brand-terracotta">
                Human Design × Life
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <h4 className="font-accent text-xs uppercase tracking-widest mb-6 text-brand-gold">
            Connect
          </h4>
          <ul className="space-y-4 font-body text-sm">
            <li>
              <Link href="/podcast" className="hover:text-brand-terracotta">
                The Messy Blueprint
              </Link>
            </li>
            <li>
              <Link href="/free-resources" className="hover:text-brand-terracotta">
                Resource Hub
              </Link>
            </li>
            <li>
              <Link href="/about" className="hover:text-brand-terracotta">
                About the Brand
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <h4 className="font-accent text-xs uppercase tracking-widest mb-6 text-brand-gold">
            Newsletter
          </h4>
          <p className="font-body text-sm mb-4">Get the weekly HD download.</p>
          <form className="flex">
            <input
              type="email"
              placeholder="Email address"
              className="bg-transparent border-b border-brand-cream/30 py-2 focus:border-brand-gold outline-none flex-grow text-sm"
            />
            <button className="ml-4 font-accent text-xs uppercase tracking-widest text-brand-gold">
              Join
            </button>
          </form>
        </div>
      </div>

      <div className="max-w-7xl mx-auto mt-10 flex flex-col md:row justify-between items-center text-[10px] uppercase tracking-[0.2em] font-accent opacity-50 space-y-4 md:space-y-0">
        <p>© 2026 UNCHARTED, LOVED. ALL RIGHTS RESERVED.</p>
        <div className="flex space-x-6">
          <Link href="/privacy">Privacy Policy</Link>
          <Link href="/terms">Terms of Service</Link>
        </div>
      </div>
    </footer>
  );
}
