/** @type {import('tailwindcss').Config} */
module.exports = {
  // ... rest of config ...
  theme: {
    extend: {
      colors: {
        brand: {
          cream: '#FAF5ED',
          terracotta: '#C4674A',
          sage: '#7A9E7E',
          inkblue: '#1E2A3A',
          gold: '#D4A843',
          blush: '#EACFC8',
          charcoal: '#3A3A3A',
        },
      },
      fontFamily: {
        display: ['var(--font-cormorant)'],
        body: ['var(--font-dm-sans)'],
        accent: ['var(--font-space-mono)'],
        handwriting: ['var(--font-caveat)'],
      },
    },
  },
  // ... rest of config ...
};
